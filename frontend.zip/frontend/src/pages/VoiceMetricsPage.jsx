import React from "react";
import VoiceMetrics from "../components/VoiceMetrics";

export default function VoiceMetricsPage() {
  return (
    <div className="p-6 text-white">
      <VoiceMetrics />
    </div>
  );
}
