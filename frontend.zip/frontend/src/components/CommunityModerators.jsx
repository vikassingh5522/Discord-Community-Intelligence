import React, { useEffect, useState } from "react";
import messages from "";

export default function CommunityModerators() {
  const [moderationRate, setModerationRate] = useState(0);
  const [moderatedMessages, setModeratedMessages] = useState([]);

  useEffect(() => {
    let moderated = messages.filter((msg) => {
      return (
        msg.voiceTone === "serious" ||
        msg.content.includes("⚠️") ||
        msg.content.includes("📢") ||
        msg.content.toLowerCase().includes("rules") ||
        msg.content.toLowerCase().includes("guidelines")
      );
    });

    const rate = ((moderated.length / messages.length) * 100).toFixed(1);

    setModeratedMessages(moderated);
    setModerationRate(rate);
  }, []);

  return (
    <div className="text-white">
      <h2 className="text-2xl font-bold mb-4">🛡 Moderator Effectiveness</h2>

      <div className="bg-[#111827] p-4 rounded-lg mb-6">
        <p className="text-lg">
          Moderation Effectiveness Score:{" "}
          <span className="text-green-400 font-bold">{moderationRate}%</span>
        </p>

        <p className="mt-2">
          Flagged Messages:{" "}
          <span className="text-yellow-400">{moderatedMessages.length}</span>
        </p>
      </div>

      <h3 className="text-xl mb-3">Key Moderated Messages</h3>

      {moderatedMessages.slice(0, 5).map((m) => (
        <div key={m.id} className="bg-[#0F172A] p-3 rounded mb-2 border border-gray-700">
          <p className="font-semibold">{m.content}</p>
          <p className="text-sm text-gray-400">{m.voiceTone} tone</p>
        </div>
      ))}
    </div>
  );
}
